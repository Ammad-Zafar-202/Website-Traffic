
const express = require("express");
const fs = require("fs");
const cors = require("cors");
const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());

const DATA_FILE = "./visitLogs.json";

app.post("/api/log", (req, res) => {
  const newLog = req.body;
  const logs = fs.existsSync(DATA_FILE) ? JSON.parse(fs.readFileSync(DATA_FILE)) : [];
  logs.push(newLog);
  fs.writeFileSync(DATA_FILE, JSON.stringify(logs, null, 2));
  res.status(201).send("Logged");
});

app.get("/api/analytics", (req, res) => {
  const logs = fs.existsSync(DATA_FILE) ? JSON.parse(fs.readFileSync(DATA_FILE)) : [];
  res.json(logs);
});

app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));
