
export const logVisit = async () => {
  const data = {
    timestamp: new Date().toISOString(),
    location: "Canada",
    ageGroup: "25-34"
  };
  try {
    await fetch("/api/log", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
  } catch (err) {
    console.error("Log failed", err);
  }
};

window.onload = logVisit;
