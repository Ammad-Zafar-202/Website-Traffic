
import React, { useEffect, useState } from "react";
import axios from "axios";
import { Line } from "react-chartjs-2";
import * as XLSX from "xlsx";

const Dashboard = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios.get("/api/analytics").then((res) => setData(res.data));
  }, []);

  const exportToExcel = () => {
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Analytics");
    XLSX.writeFile(wb, "Analytics_Report.xlsx");
  };

  const chartData = {
    labels: data.map(d => d.timestamp),
    datasets: [{
      label: "Visits",
      data: data.map(() => 1),
      fill: false,
      borderColor: "green"
    }]
  };

  return (
    <div>
      <h2>Analytics Dashboard</h2>
      <Line data={chartData} />
      <button onClick={exportToExcel}>Export to Excel</button>
    </div>
  );
};

export default Dashboard;
